#ifndef _LOGINCREDIT_H_
#define _LOGINCREDIT_H_
#include <iostream>
#include <string>
#include <cstdlib> //retrun EXIT
#include <conio.h> //getchar(), _getch()
#include <fstream> //filehandling
#include <windows.h> //Sleep(1000)
#include <iomanip> //setw(), setfill() 
#include <ios> //filehandlind
using namespace std;

//Template class so that data-type can be selected at time
template <class T>
//Class logincredentials
class LoginCredentials
{
	//private attributes
	T username, pass;
public:
	//public members
	T usernameIN, passIN; //To be taken by user and compared by private ones
	char hide; //A variable to help in hiding password
	/*Function and constructor defined in class
	  ************to make work easier*********/

	//
	LoginCredentials() //default constructors
	{

	}
	//paramterized constructor
	LoginCredentials(T username, T pass)
	{
		this->username = username;
		this->pass = pass;
	}
	//setters
	void set_username(T username)
	{
		this->username = username;
	}
	void set_pass(T pass)
	{
		this->pass = pass;
	}
	//getters
	T get_username()
	{
		return username;
	}
	T get_password()
	{
		return pass;
	}
};
#endif
