#ifndef _MAINF_H_
#define _MAINF_H_
#include"Cardeatils.h"

int sizeOfArray();
bool checkCardNumber();
void showAvailCar(CarDetails* cars, int totalCars);

//class rerserve cars
int mainMenu();

#endif // !_MAINF_H