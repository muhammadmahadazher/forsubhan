//#include "classF.h"
#include"mainF.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <conio.h>
#include <fstream>
#include <windows.h>
#include <string>
#include <iomanip>
#include <ios>
using namespace std;

bool checkCardNumber()
{
	long long creditnum = 0;

	do
	{
		cout << "Enter Credit Card Number : ";
		cin >> creditnum;
	} while (creditnum <= 0);

	long long pcc = creditnum;
	int sum = 0, count1 = 0;
	long  long divisor = 10;
	char types[20];

	// 1st condition
	while (pcc > 0)
	{
		int lastdigit = pcc % 10;
		sum = sum + lastdigit;
		pcc = pcc / 100;
	}

	// 2nd condition
	pcc = creditnum / 10;
	while (pcc > 0)
	{
		int lastsecdigit = pcc % 10;
		int db = lastsecdigit * 2;
		sum = sum + (db % 10) + (db / 10);
		pcc = pcc / 100;
	}

	// length of card number
	pcc = creditnum;
	while (pcc != 0)
	{
		pcc = pcc / 10;
		count1++;
	}

	for (int i = 0; i < count1 - 2; i++)
	{
		divisor = divisor * 10;
	}

	int firstdigit = creditnum / divisor;
	int firsttwo = creditnum / (divisor / 10);

	string payment = "Payment successful!\n";
	// if divisible then valid
	if (sum % 10 == 0)
	{
		if (firstdigit == 4 && (count1 == 13 || count1 == 16))
		{
			cout << "VALID \n";
			cout << "CARD TYPE :";

			strcpy_s(types, " VISA");
			cout << types;
			cout << endl;
			cout << payment;
			Sleep(1500);
			system("cls");
			return true;
		}
		else if ((firsttwo == 34 || firsttwo == 37) && count1 == 15)
		{
			cout << "VALID \n";
			cout << "CARD TYPE :";
			strcpy_s(types, " AMERICAN EXPRESS");
			cout << types;
			cout << endl;
			cout << payment;
			Sleep(1500);
			system("cls");
			return true;
		}
		else if ((50 < firsttwo && firsttwo < 56) && count1 == 16)
		{
			cout << "VALID \n";
			cout << "CARD TYPE :";
			strcpy_s(types, " MASTERCARD");
			cout << types;
			cout << endl;
			cout << payment;
			Sleep(1500);
			system("cls");
			return true;
		}
		else
		{
			cout << "VALID \n";
			strcpy_s(types, "OTHER CARD TYPE");
			cout << types;
			cout << endl;
			cout << payment;
			Sleep(1500);
			system("cls");
			return true;
		}
	}
	else
	{
		strcpy_s(types, "INVALID");
		cout << "Payment declined due to wrong card number\n" << types;
		Sleep(1500); system("cls");
		return false;
	}
}
//size of array 
int sizeOfArray()
{
	cout << "Do you want to upgrade ? (Y / N) : ";
	char ch;
	cin >> ch;
	switch (ch)
	{
	case 'N':
	case 'n':
		Sleep(1000);
		system("cls");
		return 10;
		break;
	case 'y':
	case 'Y':
	choices:
		Sleep(1000);
		system("cls");
		cout << "\t\t\t\tOur paid plans\n1-Standard\n2-Pro\n3-Premium\n4-Exit(Keep to free plan)\nEnter your choice: ";
		cin >> ch;
		switch (ch)
		{
		case '1':
			Sleep(1000);
			system("cls");
			cout << "You can store data of 50 cars\nPrice is 10$/month\n1-Subscribe\n0-To plans\nEnter your choice: ";
			cin >> ch;
			switch (ch)
			{
			case '0':
				goto choices;
			case '1':
				Sleep(1000);
				system("cls");
				cout << "Taking you to payment gateway!";
				Sleep(1000);
				system("cls");
			card2:
				bool num = checkCardNumber();
				if (num == true)
				{
					return 50;
				}
				else {
					Sleep(1000);
					system("cls");
					cout << "Do again!\n";
					goto card2;
				}
				break;
			}
		case '2':
			Sleep(1000);
			system("cls");
			cout << "You can store data of 200 cars\nPrice is 25$/month\n1-Subscribe\n0-To plans\nEnter your choice: ";
			cin >> ch;
			switch (ch)
			{
			case '0':
				goto choices;
			case '1':
				Sleep(1000);
				system("cls");
				cout << "Taking you to payment gateway!";
				Sleep(1000);
				system("cls");
			card1:
				bool num = checkCardNumber();
				if (num == true)
				{
					return 200;
				}
				else {
					Sleep(1000);
					system("cls");
					cout << "Do again!\n";
					goto card1;
				}
			}
			break;
		case '3':
			Sleep(1000);
			system("cls");
			cout << "You can store data of 500 cars\nPrice is 98$/month\n1-Subscribe\n0-To plans\nEnter your choice: ";
			cin >> ch;
			switch (ch)
			{
			case '0':
				goto choices;
			case '1':
				Sleep(1000);
				system("cls");
				cout << "Taking you to payment gateway!";
				Sleep(1000);
				system("cls");
			card:
				bool num = checkCardNumber();
				if (num == true)
				{
					return 500;
				}
				else {
					Sleep(1000);
					system("cls");
					cout << "Do again!\n";
					goto card;
				}
				break;
			}
		}
	}
}

//others
void showAvailCar(CarDetails* cars, int totalCars)
{
	cout << "| Car Number |  Car Brand  |  Car Type  |  License Number  |  Model  |  Distance  | onRent |\n\n";
	for (int i = 0; i < totalCars; i++)
	{
		cout << cars[i];
	}
}
