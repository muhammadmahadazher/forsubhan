<<<<<<< Updated upstream
#ifndef _CLASSF_H_
#define _CLASSF_H_
#include <iostream>
#include <string>
#include <cstdlib>
#include <conio.h>
#include <fstream>
#include <windows.h>
#include <string>
#include <iomanip>
#include <ios>
using namespace std;

//Login class
template <class T>
class LoginCredentials {
	T username, pass;
public:
	T usernameIN, passIN;
	char hide;
	LoginCredentials()
	{

	}
	LoginCredentials(T username, T pass)
	{
		this->username = username;
		this->pass = pass;
	}
	void set_username(T username)
	{
		this->username = username;
	}
	void set_pass(T pass)
	{
		this->pass = pass;
	}
	T get_username()
	{
		return username;
	}
	T get_password()
	{
		return pass;
	}
};
//car calss details
class CarDetails
{
protected:
	string license, brandName, carType;
	int model, distance;
public:
	int carNumberInDatabase; bool OnRent;//removed its default constructor here
	friend void operator >>(istream& c, CarDetails& obj);
	friend void operator <<(ostream& c, CarDetails& obj);
	friend void operator << (ofstream& c, CarDetails& obj);
	friend void operator >>(ifstream& c, CarDetails& obj);
	string getLicense();
	string getBrandName();
	string getcarType();
	int getModel();
	int getDistance();
};
//Rent class and its stuff
class Rent :public CarDetails
{
protected:
	string Name, CNIC;
	int pricePerDay;
	double days;
public:
	void setName(string);
	void setCNIC(string);
	string getCNIC();
	string getName();
	double getprice();
	void setPricePerDay(int);
	void setPrice(int);
	void setbrand(string);
	void setcartype(string);
	void setlicense(string);
	void setdistance(int);
	void setmodel(int);
	void setDetails(CarDetails& obj);
	void display();
	friend void display1(ofstream& c, Rent& obj);
	friend void operator >> (ofstream& c, Rent& obj);
	friend void operator <<(istream& c, Rent& obj);
	friend void operator <<(ifstream& c, Rent& obj);
};
//Singleton attempt
class Receipt {
	virtual void receipt(Rent&) = 0;
};
class Singleton : public Receipt
{
	static Singleton* instance;
	LoginCredentials login;
	Rent* rent;
	// Private constructor so that no objects can be created.
	Singleton()
	{
		//data = 0;
	}

public:
	static Singleton* getInstance() {
		if (!instance)
			instance = new Singleton;
		return instance;
	}
	void setRent(Rent);
	void setLogin(LoginCredentials&);
	LoginCredentials getLogins();
	Rent* getRent();
	void receipt(Rent&);
};

#endif // !_CLASSF_H
=======
//#ifndef _CLASSF_H_
//#define _CLASSF_H_
//#include <iostream>
//#include <string>
//#include <cstdlib>
//#include <conio.h>
//#include <fstream>
//#include <windows.h>
//#include <string>
//#include <iomanip>
//#include <ios>
//using namespace std;
//
////Login class
//template <class T>
//class LoginCredentials 
//{
//	T username, pass;
//public:
//	T usernameIN, passIN;
//	char hide;
//	LoginCredentials()
//	{
//
//	}
//	LoginCredentials(T username, T pass)
//	{
//		this->username = username;
//		this->pass = pass;
//	}
//	void set_username(T username)
//	{
//		this->username = username;
//	}
//	void set_pass(T pass)
//	{
//		this->pass = pass;
//	}
//	T get_username()
//	{
//		return username;
//	}
//	T get_password()
//	{
//		return pass;
//	}
//};
////car calss details
//class CarDetails
//{
//protected:
//	string license, brandName, carType;
//	int model, distance;
//public:
//	int carNumberInDatabase; bool OnRent;//removed its default constructor here
//	friend void operator >>(istream& c, CarDetails& obj);
//	friend void operator <<(ostream& c, CarDetails& obj);
//	friend void operator << (ofstream& c, CarDetails& obj);
//	friend void operator >>(ifstream& c, CarDetails& obj);
//	string getLicense();
//	string getBrandName();
//	string getcarType();
//	int getModel();
//	int getDistance();
//};
////Rent class and its stuff
//class Rent :public CarDetails
//{
//protected:
//	string Name, CNIC;
//	int pricePerDay;
//	double days;
//public:
//	void setName(string);
//	void setCNIC(string);
//	string getCNIC();
//	string getName();
//	double getprice();
//	void setPricePerDay(int);
//	void setPrice(int);
//	void setbrand(string);
//	void setcartype(string);
//	void setlicense(string);
//	void setdistance(int);
//	void setmodel(int);
//	void setDetails(CarDetails& obj);
//	void display();
//	friend void display1(ofstream& c, Rent& obj);
//	friend void operator >> (ofstream& c, Rent& obj);
//	friend void operator <<(istream& c, Rent& obj);
//	friend void operator <<(ifstream& c, Rent& obj);
//};
////Singleton attempt
//class Receipt {
//	virtual void receipt(Rent&) = 0;
//};
//class Singleton : public Receipt
//{
//	static Singleton* instance;
//	LoginCredentials<string> login;
//	Rent* rent;
//	// Private constructor so that no objects can be created.
//	Singleton()
//	{
//		//data = 0;
//	}
//
//public:
//	static Singleton* getInstance() {
//		if (!instance)
//			instance = new Singleton;
//		return instance;
//	}
//	void setRent(Rent);
//	void setLogin(LoginCredentials<string>&);
//	LoginCredentials<string> getLogins();
//	Rent* getRent();
//	void receipt(Rent&);
//};
//
//#endif // !_CLASSF_H
>>>>>>> Stashed changes
