#ifndef _SINGLETON_H_
#define _SINGLETON_H_
#include"Recipt.h"
#include"LoginCredit.h"
#include"Rent.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <conio.h>
#include <fstream>
#include <windows.h>
#include <string>
#include <iomanip>
#include <ios>
using namespace std;

class Singleton : public Receipt
{
	static Singleton* instance;
	LoginCredentials<string> login;
	Rent* rent;
	// Private constructor so that no objects can be created.
	Singleton()
	{
		//data = 0;
	}

public:
	static Singleton* getInstance() {
		if (!instance)
			instance = new Singleton;
		return instance;
	}
	void setRent(Rent);
	void setLogin(LoginCredentials<string>&);
	LoginCredentials<string> getLogins();
	Rent* getRent();
	void receipt(Rent&);
};
#endif