#include"Singleton.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <conio.h>
#include <fstream>
#include <windows.h>
#include <string>
#include <iomanip>
#include <ios>
using namespace std;

#include"Rent.h"
Singleton* Singleton::instance = 0;
void Singleton::setRent(Rent obj)
{
	rent = &obj;
}
void Singleton::setLogin(LoginCredentials<string>& obj)
{
	login = obj;
}
LoginCredentials<string> Singleton::getLogins()
{
	return login;
}
Rent* Singleton::getRent()
{
	return rent;
}
void Singleton::receipt(Rent& obj)
{
	cout << "***************************************************************************" << endl;
	cout << endl;
	cout << "       --------------------------------------------------------" << endl;
	cout << "                          CAR RENTAL SYSTEM                  " << endl;
	cout << "                         -Customer  Invoice-                  " << endl;
	cout << "       ________________________________________________________" << endl;
	cout << "      | Customer Name:" << "                    |   " << obj.getName() << endl;
	cout << "      | Car Model :" << "                       |   " << obj.carNumberInDatabase << endl;
	cout << "      | Car Company :" << "                     |   " << obj.getBrandName() << endl;
	cout << "      | Car Name :" << "                        |   " << obj.getcarType() << endl;
	//cout << "      | Number of days :" << "                  |   " << obj.days << endl;
	cout << "      | Per Day Rental Amount :" << "           |  Rs" << obj.getprice() << endl;
	cout << "       _________________________________________________________" << endl;
	cout << "\n";
	cout << "                |Total Rental Amount is : Rs" << obj.getprice() << "-------||" << endl;
	cout << "       _________________________________________________________" << endl;
	cout << "        **This is a computer generated invoice and it does not" << endl;
	cout << "                 require an authorised signature**" << endl;
	cout << "       _________________________________________________________" << endl;
	cout << "                  *Please pay the amount in cash*" << endl;
	cout << "       --------------------------------------------------------" << endl;
	cout << "\n*************************************************************************" << endl;
}