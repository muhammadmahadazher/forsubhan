#ifndef _RECIPT_H_
#define _RECIPT_H_
#include"Rent.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <conio.h>
#include <fstream>
#include <windows.h>
#include <string>
#include <iomanip>
#include <ios>
using namespace std;
class Receipt {
	virtual void receipt(Rent&) = 0;
};
#endif