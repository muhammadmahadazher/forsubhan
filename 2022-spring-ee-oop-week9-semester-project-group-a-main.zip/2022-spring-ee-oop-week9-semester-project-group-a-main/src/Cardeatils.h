#ifndef _CARDETAILS_H_
#define _CARDETAILS_H_
//including ibraries
#include <iostream>
#include <string>
#include <cstdlib> //retrun EXIT
#include <conio.h> //getchar(), _getch()
#include <fstream> //filehandling
#include <windows.h> //Sleep(1000)
#include <iomanip> //setw(), setfill() 
#include <ios> //filehandlind
using namespace std;
//class Car details
class CarDetails
{
	//protected attributes so that they can be inherited to child class
protected:
	//attributes
	string license, brandName, carType;
	int model, distance;
public:
	int carNumberInDatabase; //Issued a car number
	int OnRent; //decide weather car is on rent or not
	/*operator overloaded for simple coutand cin i.e iostream
	 Non member func because of iostream and fstream class members*/
	friend void operator >>(istream& c, CarDetails& obj); //non-member func
	friend void operator <<(ostream& c, CarDetails& obj); //non-member func
	//operator overloaded for fstream i.e filehandling
	friend void operator << (ofstream& c, CarDetails& obj); //non-member func
	friend void operator >>(ifstream& c, CarDetails& obj); //non-member func
	//getters
	string getLicense();
	string getBrandName();
	string getcarType();
	int getModel();
	int getDistance();
};

#endif
