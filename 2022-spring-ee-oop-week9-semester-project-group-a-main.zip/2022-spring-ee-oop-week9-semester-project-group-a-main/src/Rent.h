#ifndef _RENT_H_
#define _RENT_H_
#include"CarDetails.h" //Header file of car because Rent is child of CarDetails
#include <iostream>
#include <string>
#include <cstdlib> //retrun EXIT
#include <conio.h> //getchar(), _getch()
#include <fstream> //filehandling
#include <windows.h> //Sleep(1000)
#include <iomanip> //setw(), setfill() 
#include <ios> //filehandlind
using namespace std;

class Rent :public CarDetails //Taking attributes of CarDetails as public in Rent
{
protected: //Protected members
	string Name, CNIC;
	int pricePerDay;
	double days;
public:
	//getters
	string getCNIC();
	string getName();
	double getprice();
	//setters
	void setName(string);
	void setCNIC(string);
	void setPricePerDay(int);
	void setPrice(int);
	void setbrand(string);
	void setcartype(string);
	void setlicense(string);
	void setdistance(int);
	void setmodel(int);
	//member functions
	void SetDetails(CarDetails& obj);
	void display();
	//Non-Member functions
	friend void operator >> (ofstream& c, Rent& obj); //operator overloaded
	friend void operator <<(istream& c, Rent& obj);//operator overloaded
	friend void operator <<(ifstream& c, Rent& obj); //operator overloaded
};

#endif
