#include"CarDetails.h" //header file included
//including libraries
#include <iostream>
#include <string>
#include <cstdlib>
#include <conio.h>
#include <fstream>
#include <windows.h>
#include <string>
#include <iomanip>
#include <ios>
using namespace std;

//getters definition
string CarDetails::getLicense()
{
	return license;
}
string CarDetails::getBrandName()
{
	return brandName;
}
string CarDetails::getcarType()
{
	return carType;
}
int CarDetails::getModel()
{
	return model;
}
int CarDetails::getDistance()
{
	return distance;
}
//Car ofstream operator overloaded def
void operator << (ofstream& c, CarDetails& obj)
{
	c << obj.carNumberInDatabase << endl << obj.brandName << endl << obj.carType << endl << obj.license << endl << obj.model << endl << obj.distance;
	c << endl << obj.OnRent << endl;
}
//Car istream operator overloaded def
void operator >>(istream& c, CarDetails& obj)
{
	cout << "Enter brand Name: ";
	cin.ignore();
	getline(cin, obj.brandName);
	cout << "Car type: ";
	cin >> obj.carType;
	cout << "License number: ";
	cin >> obj.license;
	cout << "Model: ";
	cin >> obj.model;
	cout << "Distance: ";
	cin >> obj.distance;
	Sleep(1000);
	system("cls");
}
//Car ifstream operator overloaded def
void operator >>(ifstream& c, CarDetails& obj)
{
	c >> obj.carNumberInDatabase;
	c.seekg(1, ios::cur);
	c >> obj.brandName;
	c.seekg(1, ios::cur);
	c >> obj.carType;
	c.seekg(1, ios::cur);
	c >> obj.license;
	c.seekg(1, ios::cur);
	c >> obj.model;
	c.seekg(1, ios::cur);
	c >> obj.distance;
	c.seekg(1, ios::cur);
	c >> obj.OnRent;
	c.seekg(1, ios::cur);
}
