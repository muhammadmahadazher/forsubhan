<<<<<<< Updated upstream
#include "classF.h"
#include"mainF.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <conio.h>
#include <fstream>
#include <windows.h>
#include <string>
#include <iomanip>
#include <ios>
#include <algorithm>
using namespace std;

//Login class Func Defs
//
//LoginCredentials::LoginCredentials()
//{
//
//}
//LoginCredentials::LoginCredentials(string username, string pass)
//{
//	this->username = username;
//	this->pass = pass;
//}
////setters login
//void LoginCredentials::set_username(string username)
//{
//	this->username = username;
//}
//void LoginCredentials::set_pass(string pass)
//{
//	this->pass = pass;
//}
////getters login
//string LoginCredentials::get_username()
//{
//	return username;
//}
//string LoginCredentials::get_password()
//{
//	return pass;
//}
//car class
//car class
string CarDetails::getLicense()
{
	return license;
}
string CarDetails::getBrandName()
{
	return brandName;
}
string CarDetails::getcarType()
{
	return carType;
}
int CarDetails::getModel()
{
	return model;
}
int CarDetails::getDistance()
{
	return distance;
}
//Car operators
void operator << (ofstream& c, CarDetails& obj)
{
	c << obj.carNumberInDatabase << endl << obj.brandName << endl << obj.carType << endl << obj.license << endl << obj.model << endl << obj.distance;
	c << endl << obj.OnRent << endl;
}
void operator >>(istream& c, CarDetails& obj)
{
	cout << "Enter brand Name: ";
	cin.ignore();
	getline(cin, obj.brandName);
	cout << "Car type: ";
	cin >> obj.carType;
	cout << "License number: ";
	cin >> obj.license;
	cout << "Model: ";
	cin >> obj.model;
	cout << "Distance: ";
	cin >> obj.distance;
	Sleep(1000);
	system("cls");
}
void operator >>(ifstream& c, CarDetails& obj)
{
	c >> obj.carNumberInDatabase;
	c.seekg(1, ios::cur);
	c >> obj.brandName;
	c.seekg(1, ios::cur);
	c >> obj.carType;
	c.seekg(1, ios::cur);
	c >> obj.license;
	c.seekg(1, ios::cur);
	c >> obj.model;
	c.seekg(1, ios::cur);
	c >> obj.distance;
	c.seekg(1, ios::cur);
	c >> obj.OnRent;
	c.seekg(1, ios::cur);
}
//Rent class funcs
void Rent::setlicense(string a)
{
	license = a;
}
void Rent::setbrand(string a)
{
	brandName = a;
}
void Rent::setcartype(string a)
{
	carType = a;
}
void Rent::setmodel(int a)
{
	model = a;
}
void Rent::setdistance(int a)
{
	distance = a;
}
double Rent::getprice()
{
	return days;
}
void Rent::display()
{
	cout << "|     " << carNumberInDatabase << "      | " << brandName << "      |   " << carType << "  |    " << license << "       |    " << model << " |    " << Name;
	cout << "    |    " << CNIC << "  |  " << days << endl << endl;
}
void Rent::setPricePerDay(int pricePerDay)
{
	this->pricePerDay = pricePerDay;
}
void Rent::setPrice(int days)
{
	this->days = days * pricePerDay;
}
void Rent::setDetails(CarDetails& obj)
{
	brandName = obj.getBrandName();
	carType = obj.getcarType();
	model = obj.getModel();
	distance = obj.getDistance();
	license = obj.getLicense();
	carNumberInDatabase = obj.carNumberInDatabase;
	obj.OnRent = true;
}
void Rent::setName(string Name)
{
	this->Name = Name;
}
void Rent::setCNIC(string CNIC)
{
	this->CNIC = CNIC;
}
string Rent::getCNIC()
{
	return CNIC;
}
string Rent::getName()
{
	return Name;
}
void display1(ofstream& c, Rent& obj)
{
	c << obj.carNumberInDatabase;
	c << endl << obj.brandName;
	c << endl << obj.carType;
	c << endl << obj.CNIC;
	c << endl << obj.days;
	c << endl << obj.distance;
	c << endl << obj.license;
	c << endl << obj.model;
	c << endl << obj.Name;
	c << endl << obj.OnRent;
	c << endl << obj.pricePerDay;
	c << endl;
}
void operator << (ostream& c, CarDetails& obj)
{
	cout << setw(10) << obj.carNumberInDatabase << " | " << setw(20)
		<< obj.brandName << setw(20) << "      |   " << setw(20) << obj.carType << setw(20) << "  |    " << setw(10) << obj.license << setw(20) << "       |    " << setw(10) << obj.model << " |    " << setw(20) << obj.distance;
	cout << setw(20) << "    |    " << setw(10) << obj.OnRent << endl << endl;
}
//singleton data
Singleton* Singleton::instance = 0;
void Singleton::setRent(Rent obj)
{
	rent = &obj;
}
void Singleton::setLogin(LoginCredentials& obj)
{
	login = obj;
}
LoginCredentials Singleton::getLogins()
{
	return login;
}
Rent* Singleton::getRent()
{
	return rent;
}
void Singleton::receipt(Rent& obj)
{
	cout << "***************************************************************************" << endl;
	cout << endl;
	cout << "       --------------------------------------------------------" << endl;
	cout << "                          CAR RENTAL SYSTEM                  " << endl;
	cout << "                         -Customer  Invoice-                  " << endl;
	cout << "       ________________________________________________________" << endl;
	cout << "      | Customer Name:" << "                    |   " << obj.getName()<< endl;
	cout << "      | Car Model :" << "                       |   " << obj.carNumberInDatabase << endl;
	cout << "      | Car Company :" << "                     |   " << obj.getBrandName() << endl;
	cout << "      | Car Name :" << "                        |   " << obj.getcarType() << endl;
	//cout << "      | Number of days :" << "                  |   " << obj.days << endl;
	cout << "      | Per Day Rental Amount :" << "           |  Rs" << obj.getprice() << endl;
	cout << "       _________________________________________________________" << endl;
	cout << "\n";
	cout << "                |Total Rental Amount is : Rs" << obj.getprice() << "-------||" << endl;
	cout << "       _________________________________________________________" << endl;
	cout << "        **This is a computer generated invoice and it does not" << endl;
	cout << "                 require an authorised signature**" << endl;
	cout << "       _________________________________________________________" << endl;
	cout << "                  *Please pay the amount in cash*" << endl;
	cout << "       --------------------------------------------------------" << endl;
	cout << "\n*************************************************************************" << endl;
}
=======
//#include "classF.h"
//#include"mainF.h"
//#include <iostream>
//#include <string>
//#include <cstdlib>
//#include <conio.h>
//#include <fstream>
//#include <windows.h>
//#include <string>
//#include <iomanip>
//#include <ios>
//#include <algorithm>
//using namespace std;
//
////Login class Func Defs
////
////LoginCredentials::LoginCredentials()
////{
////
////}
////LoginCredentials::LoginCredentials(string username, string pass)
////{
////	this->username = username;
////	this->pass = pass;
////}
//////setters login
////void LoginCredentials::set_username(string username)
////{
////	this->username = username;
////}
////void LoginCredentials::set_pass(string pass)
////{
////	this->pass = pass;
////}
//////getters login
////string LoginCredentials::get_username()
////{
////	return username;
////}
////string LoginCredentials::get_password()
////{
////	return pass;
////}
////car class
////car class
//string CarDetails::getLicense()
//{
//	return license;
//}
//string CarDetails::getBrandName()
//{
//	return brandName;
//}
//string CarDetails::getcarType()
//{
//	return carType;
//}
//int CarDetails::getModel()
//{
//	return model;
//}
//int CarDetails::getDistance()
//{
//	return distance;
//}
////Car operators
//void operator << (ofstream& c, CarDetails& obj)
//{
//	c << obj.carNumberInDatabase << endl << obj.brandName << endl << obj.carType << endl << obj.license << endl << obj.model << endl << obj.distance;
//	c << endl << obj.OnRent << endl;
//}
//void operator >>(istream& c, CarDetails& obj)
//{
//	cout << "Enter brand Name: ";
//	cin.ignore();
//	getline(cin, obj.brandName);
//	cout << "Car type: ";
//	cin >> obj.carType;
//	cout << "License number: ";
//	cin >> obj.license;
//	cout << "Model: ";
//	cin >> obj.model;
//	cout << "Distance: ";
//	cin >> obj.distance;
//	Sleep(1000);
//	system("cls");
//}
//void operator >>(ifstream& c, CarDetails& obj)
//{
//	c >> obj.carNumberInDatabase;
//	c.seekg(1, ios::cur);
//	c >> obj.brandName;
//	c.seekg(1, ios::cur);
//	c >> obj.carType;
//	c.seekg(1, ios::cur);
//	c >> obj.license;
//	c.seekg(1, ios::cur);
//	c >> obj.model;
//	c.seekg(1, ios::cur);
//	c >> obj.distance;
//	c.seekg(1, ios::cur);
//	c >> obj.OnRent;
//	c.seekg(1, ios::cur);
//}
////Rent class funcs
//void Rent::setlicense(string a)
//{
//	license = a;
//}
//void Rent::setbrand(string a)
//{
//	brandName = a;
//}
//void Rent::setcartype(string a)
//{
//	carType = a;
//}
//void Rent::setmodel(int a)
//{
//	model = a;
//}
//void Rent::setdistance(int a)
//{
//	distance = a;
//}
//double Rent::getprice()
//{
//	return days;
//}
//void Rent::display()
//{
//	cout << "|     " << carNumberInDatabase << "      | " << brandName << "      |   " << carType << "  |    " << license << "       |    " << model << " |    " << Name;
//	cout << "    |    " << CNIC << "  |  " << days << endl << endl;
//}
//void Rent::setPricePerDay(int pricePerDay)
//{
//	this->pricePerDay = pricePerDay;
//}
//void Rent::setPrice(int days)
//{
//	this->days = days * pricePerDay;
//}
//void Rent::setDetails(CarDetails& obj)
//{
//	brandName = obj.getBrandName();
//	carType = obj.getcarType();
//	model = obj.getModel();
//	distance = obj.getDistance();
//	license = obj.getLicense();
//	carNumberInDatabase = obj.carNumberInDatabase;
//	obj.OnRent = true;
//}
//void Rent::setName(string Name)
//{
//	this->Name = Name;
//}
//void Rent::setCNIC(string CNIC)
//{
//	this->CNIC = CNIC;
//}
//string Rent::getCNIC()
//{
//	return CNIC;
//}
//string Rent::getName()
//{
//	return Name;
//}
//void display1(ofstream& c, Rent& obj)
//{
//	c << obj.carNumberInDatabase;
//	c << endl << obj.brandName;
//	c << endl << obj.carType;
//	c << endl << obj.CNIC;
//	c << endl << obj.days;
//	c << endl << obj.distance;
//	c << endl << obj.license;
//	c << endl << obj.model;
//	c << endl << obj.Name;
//	c << endl << obj.OnRent;
//	c << endl << obj.pricePerDay;
//	c << endl;
//}
//void operator << (ostream& c, CarDetails& obj)
//{
//	cout << setw(10) << obj.carNumberInDatabase << " | " << setw(20)
//		<< obj.brandName << setw(20) << "      |   " << setw(20) << obj.carType << setw(20) << "  |    " << setw(10) << obj.license << setw(20) << "       |    " << setw(10) << obj.model << " |    " << setw(20) << obj.distance;
//	cout << setw(20) << "    |    " << setw(10) << obj.OnRent << endl << endl;
//}
////singleton data
//Singleton* Singleton::instance = 0;
//void Singleton::setRent(Rent obj)
//{
//	rent = &obj;
//}
//void Singleton::setLogin(LoginCredentials<string>& obj)
//{
//	login = obj;
//}
//LoginCredentials<string> Singleton::getLogins()
//{
//	return login;
//}
//Rent* Singleton::getRent()
//{
//	return rent;
//}
//void Singleton::receipt(Rent& obj)
//{
//	cout << "***************************************************************************" << endl;
//	cout << endl;
//	cout << "       --------------------------------------------------------" << endl;
//	cout << "                          CAR RENTAL SYSTEM                  " << endl;
//	cout << "                         -Customer  Invoice-                  " << endl;
//	cout << "       ________________________________________________________" << endl;
//	cout << "      | Customer Name:" << "                    |   " << obj.getName() << endl;
//	cout << "      | Car Model :" << "                       |   " << obj.carNumberInDatabase << endl;
//	cout << "      | Car Company :" << "                     |   " << obj.getBrandName() << endl;
//	cout << "      | Car Name :" << "                        |   " << obj.getcarType() << endl;
//	//cout << "      | Number of days :" << "                  |   " << obj.days << endl;
//	cout << "      | Per Day Rental Amount :" << "           |  Rs" << obj.getprice() << endl;
//	cout << "       _________________________________________________________" << endl;
//	cout << "\n";
//	cout << "                |Total Rental Amount is : Rs" << obj.getprice() << "-------||" << endl;
//	cout << "       _________________________________________________________" << endl;
//	cout << "        **This is a computer generated invoice and it does not" << endl;
//	cout << "                 require an authorised signature**" << endl;
//	cout << "       _________________________________________________________" << endl;
//	cout << "                  *Please pay the amount in cash*" << endl;
//	cout << "       --------------------------------------------------------" << endl;
//	cout << "\n*************************************************************************" << endl;
//}
>>>>>>> Stashed changes
