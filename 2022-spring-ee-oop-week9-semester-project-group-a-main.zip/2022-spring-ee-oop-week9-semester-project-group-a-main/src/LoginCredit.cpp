//Member functions defined in class already
//No non-member function
#include"LoginCredit.h"
