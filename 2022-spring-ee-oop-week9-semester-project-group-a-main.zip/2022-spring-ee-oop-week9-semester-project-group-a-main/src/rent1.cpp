#include"Rent.h"
#include<iostream>
#include <fstream>
#include <iomanip>
using namespace std;

void Rent::setlicense(string a)
{
	license = a;
}
void Rent::setbrand(string a)
{
	brandName = a;
}
void Rent::setcartype(string a)
{
	carType = a;
}
void Rent::setmodel(int a)
{
	model = a;
}
void Rent::setdistance(int a)
{
	distance = a;
}
double Rent::getprice()
{
	return days;
}
void Rent::display()
{
	cout << "|     " << carNumberInDatabase << "      | " << brandName << "      |   " << carType << "  |    " << license << "       |    " << model << " |    " << Name;
	cout << "    |    " << CNIC << "  |  " << days << endl << endl;
}
void Rent::setPricePerDay(int pricePerDay)
{
	this->pricePerDay = pricePerDay;
}
void Rent::setPrice(int days)
{
	this->days = days * pricePerDay;
}
void Rent::SetDetails(CarDetails& obj)
{
	brandName = obj.getBrandName();
	carType = obj.getcarType();
	model = obj.getModel();
	distance = obj.getDistance();
	license = obj.getLicense();
	carNumberInDatabase = obj.carNumberInDatabase;
	obj.OnRent = 1;
}
void Rent::setName(string Name)
{
	this->Name = Name;
}
void Rent::setCNIC(string CNIC)
{
	this->CNIC = CNIC;
}
string Rent::getCNIC()
{
	return CNIC;
}
string Rent::getName()
{
	return Name;
}
void operator >> (ofstream& c, Rent& obj)
{
	c << obj.carNumberInDatabase;
	c << endl << obj.brandName;
	c << endl << obj.carType;
	c << endl << obj.CNIC;
	c << endl << obj.days;
	c << endl << obj.distance;
	c << endl << obj.license;
	c << endl << obj.model;
	c << endl << obj.Name;
	c << endl << obj.OnRent;
	c << endl << obj.pricePerDay;
}
void operator << (ostream& c, CarDetails& obj)
{
	cout << setw(7) << obj.carNumberInDatabase <<setw(7) << "|" << setw(7)
		<< obj.brandName << setw(7) << "|" << setw(9) << obj.carType << setw(4) << "|" << setw(8) << obj.license << setw(11) << "|" << setw(6) << obj.model <<setw(4) << "|" << setw(10) << obj.distance;
	cout << setw(3) << "|" << setw(5) << obj.OnRent << endl << endl;
}
