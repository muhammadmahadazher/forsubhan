//#include"classF.h"
#include"mainF.h"
#include"Cardetails.h"
//#include"ClassF.h"
#include"LoginCredit.h"
#include"MainF.h"
#include"Recipt.h"
#include"Rent.h"
#include"Singleton.h"

#include <iostream>
#include <string>
#include <cstdlib>
#include <conio.h>
#include <fstream>
#include <windows.h>
#include <string>
#include <iomanip>
#include <ios>
using namespace std;

int main()
{
	int premium = 0;
	static int n = 10;
	ifstream check("first_time_check.txt", ios::in);
	int checkVar = 0;
	while (true)
	{
		if (check.eof())
			break;
		check >> checkVar;
	}
	string st;
	ifstream file("openingtext.txt");
	while (!file.eof()) {
		getline(file, st);
		cout << st;
		cout << endl;
	}
	cout << endl;
	cout << "**************************" << endl;
	cout << "\nPress the enter key to continue.....";
	getchar();

	system("cls");

	if (checkVar == 1)
	{
		cout << "You are running on a free version of this Programme\n";
	}
	check.close();
	ifstream premiumcheck("premium.txt", ios::in);
	premiumcheck >> premium;
	premiumcheck.seekg(1, ios::cur);
	premiumcheck >> n;
	if (n <= 10)
	{
		n = sizeOfArray();
	}
Restart:
	ofstream premiumCheck("premium.txt");
	premiumCheck << premium;
	premiumCheck << endl << n;
	premiumCheck.close();
	int pre = n;
	LoginCredentials<string> AdminLogin("Admin", "Admin1234");
	CarDetails* cars = new CarDetails[n];
	Rent* rents = new Rent[n];
	Singleton* customer = customer->getInstance();
	int totalCars = 0, rentNumber = 0;
login:
	cout << "\n\t\t\t\t\t\t\tWelcome\n\t\t\t\t\t\tITU Car Rental System\n";
	cout << "1-Customer Login\n2-Admin Login\nEnter your choice: "; int loginch;
	cin >> loginch;
	if (loginch != 1)
	{
		cout << "Enter your Username: ";
		cin >> AdminLogin.usernameIN;
		if (AdminLogin.usernameIN.compare(AdminLogin.get_username()) == 0)
		{
			system("cls");
			cout << "Enter password: ";
			AdminLogin.hide = _getch();
			while (AdminLogin.hide != 13)
			{//ASCII code for enter is 13 :)
				AdminLogin.passIN.push_back(AdminLogin.hide);
				cout << '*';
				AdminLogin.hide = _getch();
			}
			if (AdminLogin.passIN.compare(AdminLogin.get_password()) == 0)
			{
				system("cls");
				cout << "\a\aAdmin access granted!\n";
				Sleep(1000);
				system("cls");
			adminOptions:
				check.open("first_time_check.txt", ios::in);
				int checkVar = 0;
				while (true)
				{
					if (check.eof())
						break;
					check >> checkVar;
				}
				if (checkVar == 1)
				{
					checkVar++;
					ofstream update("first_time_check.txt", ios::out);
					update << checkVar;
					update.close();
					cout << "This program is running for the first time on your system\n";
					cout << "This information would not be asked again but you can always modify it later\n";
					Sleep(3000);
					system("cls");
					cout << "How many cars you have: ";
					cin >> totalCars;
					for (int i = 0; i < totalCars; i++)
					{
						cout << "Car number " << i + 1 << endl;
						cin >> cars[i];
						cars[i].carNumberInDatabase = i + 1;
						cars[i].OnRent = 0;
					}
					ofstream CarDetails("CarDetails.txt");
					CarDetails << totalCars << endl;
					for (int i = 0; i < totalCars; i++)
					{
						CarDetails << cars[i];
					}
					CarDetails.close();
					goto adminOptions;
				}
				else
				{
					check.close();
					ifstream cardetails("CarDetails.txt", ios::in);
					cardetails >> totalCars;
					cardetails.seekg(1, ios::cur);
					for (int i = 0; i < totalCars; i++)
					{
						cardetails >> cars[i];
					}
					cardetails.close();
					ifstream rentdetails("RenDetails.txt", ios::in);
					rentdetails >> rentNumber;
					rentdetails.seekg(1, ios::cur);
					for (int i = 0; i < rentNumber; i++)
					{
						string input; int j;
						rentdetails >> j;
						rents[i].carNumberInDatabase = j;
						rentdetails.seekg(1, ios::cur);
						rentdetails >> input;
						rents[i].setbrand(input);
						rentdetails.seekg(1, ios::cur);
						rentdetails >> input;
						rents[i].setcartype(input);
						rentdetails.seekg(1, ios::cur);
						rentdetails >> input;
						rents[i].setCNIC(input);
						rentdetails.seekg(1, ios::cur);
						rentdetails >> j;
						rents[i].setPrice(j);
						rentdetails.seekg(1, ios::cur);
						rentdetails >> j;
						rents[i].setdistance(j);
						rentdetails.seekg(1, ios::cur);
						rentdetails >> input;
						rents[i].setlicense(input);
						rentdetails.seekg(1, ios::cur);
						rentdetails >> j;
						rents[i].setmodel(j);
						rentdetails.seekg(1, ios::cur);
						rentdetails >> input;
						rents[i].setName(input);
						rentdetails.seekg(1, ios::cur);
						rentdetails >> j;
						rents[i].OnRent = j;
						rentdetails.seekg(1, ios::cur);
						rentdetails >> j;
						rents[i].setPricePerDay(j);
					}
					cout << "Welcome Back!\n";
					if (n == 10)
					{
						cout << "You are running free version\nYou can Update it anytime :)\n";
					}
					else if (n == 50)
					{
						cout << "Standard Member\n";
					}
					else if (n == 200)
					{
						cout << "Pro Member\n";
					}
					else if (n == 500)
					{
						cout << "Premium Member\n";
					}
				mainmenu:
				hi:
					cout << "\n\t\t\t-----------------------------\n\t\t\t|\t\t\t    |" << endl;
					cout << "\t\t\t|   CAR MANAGEMENT SYSTEM   |\n\t\t\t|\t\t\t    |" << endl;
					cout << "\t\t\t-----------------------------\n\t\t\t|\t\t\t    |" << endl;
					cout << "\t\t\t| 1. Issue a car            |" << endl;
					cout << "\t\t\t| 2. Return a car           |" << endl;
					cout << "\t\t\t| 3. Add a car in database  |" << endl;
					cout << "\t\t\t| 4. Delete a car from data |" << endl;
					cout << "\t\t\t| 5. All car details        |" << endl;
					cout << "\t\t\t| 6. Rent details           |" << endl;
					cout << "\t\t\t| 7. Upgrade plan           |" << endl;
					cout << "\t\t\t| 8. Logout                 |\n\t\t\t|";
					cout << "\t\t\t    |\n\t\t\t-----------------------------" << endl;
					cout << "\t\t\t|Choose Option:[1/2/3/4/5/6/7/8]|" << endl;
					cout << "\t\t\t-----------------------------\n" << endl;
					cout << "\n**************************************************************************" << endl;
					cout << "Enter Option: ";
					int ch = 0; cin >> ch;
					Sleep(1000);
					system("cls");
					switch (ch)
					{
					case 2:
					{
						cout << "Enter car number to be deleted from data: ";
						int num; cin >> num;
						num--;
						for (int i = num; i < totalCars - 1; i++)
						{
							rents[i] = rents[i + 1];
						}
						delete[rentNumber] rents;
						ofstream CarDetails1("CarDetails.txt");
						CarDetails1 << totalCars << endl;
						for (int i = 0; i < totalCars; i++)
						{
							CarDetails1 << cars[i];
						}
						CarDetails1.close();
						totalCars--;
						cout << "Data deleted!\n";
						ofstream rentdetails1;
						rentdetails1.open("Rendetails.txt", ios::out);
						rentdetails1 << rentNumber << endl;
						for (int i = 0; i < rentNumber; i++)
						{
							rentdetails1 >> rents[i];
						}
						rentdetails.close();
						goto mainmenu;
					}
					case 3:
					{
						cout << "Enter cars " << totalCars + 1 << " details: ";
						cout << endl;
						cin >> cars[totalCars];
						cars[totalCars].carNumberInDatabase = totalCars + 1;
						ofstream CarDetails1("CarDetails.txt");
						CarDetails1 << totalCars << endl;
						for (int i = 0; i < totalCars; i++)
						{
							CarDetails1 << cars[i];
						}
						CarDetails1.close();
						totalCars++;
						Sleep(1000);
						system("cls");
						goto mainmenu;
					}
					case 4: {
						cout << "Enter car number to be deleted from data: ";
						int num; cin >> num;
						num--;
						for (int i = num; i < totalCars - 1; i++)
						{
							cars[i] = cars[i + 1];
						}
						ofstream CarDetails1("CarDetails.txt");
						CarDetails1 << totalCars << endl;
						for (int i = 0; i < totalCars; i++)
						{
							CarDetails1 << cars[i];
						}
						CarDetails1.close();
						rentNumber--;
						rentNumber--;
						cout << "Data deleted!\n";
						Sleep(1000);
						system("cls");
						goto mainmenu;
					}
					case 7:
						n = sizeOfArray();
						if (n > pre)
						{
							cout << "Congrats you are now premium member\n";
							pre = n;
							Sleep(1000);
							system("cls");
						}
						goto Restart;
					case 6:
					{
						cout << "| Car Number |  Car Brand  |" << setw(20) << "  Car Type  | " << setw(5) << " License Number  |" << setw(5) << "  Model  |" << setw(20) << "  Customer Name  |" << setw(5) << "     CNIC     |" << setw(5) << "  Price  |\n\n";
						for (int i = 0; i < rentNumber; i++)
						{
							if (rents[i].carNumberInDatabase == -842150451)
								cout << " " << endl;
							else
							rents[i].display();
						}
						cout << "Press enter to go back\n";
						_getch();
						goto mainmenu;
					}
					case 1:
					{
					case1:
						cout << "Welcome to renting wizard\n";
						cout << "Which car you want to rent enter number of car: ";
						int num; cin >> num;
						for (int i = 0; i < totalCars; i++)
						{
							if (cars[i].carNumberInDatabase == num && cars[i].OnRent == 1)
							{
								cout << "That car is already on Rent :(";
								Sleep(1000);
								system("cls");
								goto case1;
							}
						}
						cout << "Customer name: ";
						string name; cin.ignore(); getline(cin, name);
						rents[rentNumber].setName(name);
						cout << "Enter CNIC: ";
						string CNIC;  getline(cin, CNIC);
						rents[rentNumber].setCNIC(CNIC);
						cout << "Enter rent of per day: ";
						int price = 0; cin >> price;
						rents[rentNumber].setPricePerDay(price);
						cout << "Enter number of days (can also enter 0.5,1.5... etc): ";
						int days = 0; cin >> days;
						rents[rentNumber].setPrice(days);

						for (int i = 0; i < totalCars; i++)
						{
							if (cars[i].carNumberInDatabase == num)
							{
								rents[rentNumber].setbrand(cars[i].getBrandName());
								rents[rentNumber].setcartype(cars[i].getcarType());
								rents[rentNumber].setmodel(cars[i].getModel());
								rents[rentNumber].setlicense(cars[i].getLicense());
								rents[rentNumber].carNumberInDatabase = cars[i].carNumberInDatabase;
								cars[i].OnRent = 1;
							}
						}
						rentNumber++;
						ofstream Cardetails("CarDetails.txt", ios::out);
						Cardetails << totalCars << endl;
						for (int i = 0; i < totalCars; i++)
						{
							Cardetails << cars[i + 1];
						}
						Cardetails.close();
						ofstream rentdetails("RenDetails.txt", ios::out);
						rentdetails << rentNumber << endl;
						for (int i = 0; i < totalCars; i++)
						{
							rentdetails << rents[i];
							rentdetails << cars[i];
						}
						rentdetails.close();
						Sleep(1000);
						system("cls");
						goto mainmenu;
					}
					case 5:
					{

						showAvailCar(cars, totalCars); //def for this in comments block above
						cout << "Press enter to go back\n";
						_getch();
						goto mainmenu;
					}
					case 8:
					{
						goto login;
					}
					default:
						std::cout << "Invalid option Choosen\n";
						break;
					}
				}

			}

			else
			{
				system("cls");
				cout << "Wrong Password\n\a";
			}
		}
		else
		{
			system("cls");
			cout << "Wrong username\n\a";
		}
	}
	else
	{
		ifstream cardetails("CarDetails.txt", ios::in);
		cardetails >> totalCars;
		cardetails.seekg(1, ios::cur);
		for (int i = 0; i < totalCars; i++)
		{
			cardetails >> cars[i];
		}
		cardetails.close();
		ifstream rentdetails("RenDetails.txt", ios::in);
		rentdetails >> rentNumber;
		rentdetails.seekg(1, ios::cur);
		for (int i = 0; i < rentNumber; i++)
		{
			string input; int j;
			rentdetails >> j;
			rents[i].carNumberInDatabase = j;
			rentdetails.seekg(1, ios::cur);
			rentdetails >> input;
			rents[i].setbrand(input);
			rentdetails.seekg(1, ios::cur);
			rentdetails >> input;
			rents[i].setcartype(input);
			rentdetails.seekg(1, ios::cur);
			rentdetails >> input;
			rents[i].setCNIC(input);
			rentdetails.seekg(1, ios::cur);
			rentdetails >> j;
			rents[i].setPrice(j);
			rentdetails.seekg(1, ios::cur);
			rentdetails >> j;
			rents[i].setdistance(j);
			rentdetails.seekg(1, ios::cur);
			rentdetails >> input;
			rents[i].setlicense(input);
			rentdetails.seekg(1, ios::cur);
			rentdetails >> j;
			rents[i].setmodel(j);
			rentdetails.seekg(1, ios::cur);
			rentdetails >> input;
			rents[i].setName(input);
			rentdetails.seekg(1, ios::cur);
			rentdetails >> j;
			rents[i].OnRent = j;
			rentdetails.seekg(1, ios::cur);
			rentdetails >> j;
			rents[i].setPricePerDay(j);
		}
		LoginCredentials<string> logins;
		Rent temp;
		cout << "Enter customer Name: ";
		string name;
		cin >> name;
		cout << "Finding your detail in data base\n";
		for (int i = 0; i < rentNumber; i++)
		{
			if (rents[i].getName().compare(name) == 0)
			{
				customer->setRent(rents[i]);
				logins.set_pass(rents[i].getCNIC());
				logins.set_username(rents[i].getName());
				customer->setLogin(logins);
				temp = rents[i];
				Sleep(1000);
				system("cls");
				cout << "Details Found!\n";
				break;
			}
		}
		cout << "Enter your CNIC as password: ";
		string CNIC;
		cin >> CNIC;
		if (customer->getLogins().get_password().compare(CNIC) == 0)
		{
			Sleep(1000);
			system("cls");
			customer->receipt(temp);
			Sleep(10000);
			system("cls");
			goto login;
		}
	}
}
